<?php 
    require_once('db.php');

    function login($username, $password){
        $con = getConnection();
        $sql = "select * from users where username='{$username}' and password='{$password}'";
        $result = mysqli_query($con, $sql);
        $count = mysqli_num_rows($result);

        if($count == 1){
            return true;
        }else{
            return false;
        }
    }

    function addUser($username, $password, $name, $email, $gender, $dateofbirth){
        $con = getConnection();
        $sql = "INSERT INTO users (username, password, name, email, gender, dateofbirth) VALUES ('$username', '$password', '$name', '$email', '$gender', '$dateofbirth')";
        if(mysqli_query($con, $sql)){
           return true;
        }else{
            return false;
        }
    }

    function getUserInfo(){
        $con = getConnection();
        $username = $_SESSION['username'];
        $sql = "SELECT * FROM users WHERE username='$username'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_assoc($result);
        return $row;
    }

    function updateUser()
    {
        $con = getConnection();
        $username = $_SESSION['username'];
        $newUsername = $_POST['username'];
        $newPassword = $_POST['password'];
        $newName = $_POST['name'];
        $newEmail = $_POST['email'];
        $newGender = $_POST['gender'];
        $newDateofbirth = $_POST['dateofbirth'];

        $updateSql = "UPDATE users SET  password='$newPassword', name='$newName', email='$newEmail', gender='$newGender', dateofbirth='$newDateofbirth' WHERE username='$username'";

        if (mysqli_query($con, $updateSql)) {
            return true;
        } else {
            return false;
        }
    }

    

    

    function createPost($content, $username) {
        $con = getConnection();
        $sql = "INSERT INTO posts (content, username) VALUES (?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("ss", $content, $username);
    
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    function getAllPosts(){
        $con = getConnection();
        $sql = "SELECT * FROM posts ORDER BY timestamp DESC";
        $result = mysqli_query($con, $sql);
        $posts = [];

        while($row = mysqli_fetch_assoc($result)){
            $posts[] = $row;
        }

        return $posts;
    }

    function storePictureInfo($username, $imageData) {
        $con = getConnection();
        $timestamp = date('Y-m-d H:i:s');
        $sql = "INSERT INTO pictures (username, image_data, timestamp) VALUES ('$username', '$imageData', '$timestamp')";
        
        if (mysqli_query($con, $sql)) {
            return true;
        } else {
            return false;
        }
    }

    function getLatestPicture() {
        $con = getConnection();
        $sql = "SELECT * FROM pictures ORDER BY timestamp DESC LIMIT 1";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_assoc($result);
        return $row;
    }

    function searchUsers($searchTerm) {
        $con = getConnection();
        $searchTerm = mysqli_real_escape_string($con, $searchTerm);
    
        $sql = "SELECT * FROM users WHERE username LIKE '%$searchTerm%' OR name LIKE '%$searchTerm%'";
        $result = mysqli_query($con, $sql);
    
        $users = [];
    
        while ($row = mysqli_fetch_assoc($result)) {
            $users[] = $row;
        }
    
        return $users;
    }

    function getLatestPictureByUsername($username) {
        $con = getConnection();
        $sql = "SELECT * FROM pictures WHERE username = '$username' ORDER BY timestamp DESC LIMIT 1";
        $result = mysqli_query($con, $sql);
    
        if ($result && mysqli_num_rows($result) > 0) {
            return mysqli_fetch_assoc($result);
        } else {
            return null;
        }
    }

    function isFollowing($followerUsername, $followingUsername) {
        $con = getConnection();
        $sql = "SELECT * FROM followers WHERE follower_username = '$followerUsername' AND following_username = '$followingUsername'";
        $result = mysqli_query($con, $sql);
    
        if ($result && mysqli_num_rows($result) > 0) {
            return true;
        } else {
            return false;
        }
    }
    function followUser($followerUsername, $followingUserId) {
        global $conn;
    
        $followerId = getUserIdByUsername($followerUsername);
    
        if ($followerId !== false) {
            $query = "INSERT INTO followers (follower_id, following_id) VALUES (?, ?)";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, 'ii', $followerId, $followingUserId);
    
            if (mysqli_stmt_execute($stmt)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    
    function unfollowUser($followerUsername, $followingUserId) {
        global $conn;
    
        $followerId = getUserIdByUsername($followerUsername);
    
        if ($followerId !== false) {
            $query = "DELETE FROM followers WHERE follower_id = ? AND following_id = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, 'ii', $followerId, $followingUserId);
    
            if (mysqli_stmt_execute($stmt)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


?>