<?php 

    header('location: view/login.php')

?>