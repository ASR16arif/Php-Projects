<?php
session_start();
require_once('../model/userModel.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_term'])) {
    $searchTerm = $_POST['search_term'];
    $searchResults = searchUsers($searchTerm);

    if (!empty($searchResults)) {
        foreach ($searchResults as $user) {
            echo '<div class="searched-user">';
            
            // Display user's profile picture
            $profilePicture = getLatestPictureByUsername($user['username']);
            if ($profilePicture) {
                $base64 = base64_encode($profilePicture['image_data']);
                echo '<div class="picture-box"><img src="data:image/jpeg;base64,' . $base64 . '" alt="' . $user['username'] . '"></div>';
            } else {
                echo '<div class="picture-box"></div>';
            }
            
            echo '<p>' . $user['username'] . '</p>';
            echo '<button onclick="viewProfile(' . $user['id'] . ')">View</button>';
            
             // Check if the logged in user is already following this user
            $loggedInUsername = $_SESSION['username'];
            if (isFollowing($loggedInUsername, $user['username'])) {
                echo '<button class="follow-btn" onclick="toggleFollow(' . $user['id'] . ', true)">Following</button>';
            } else {
                echo '<button class="follow-btn" onclick="toggleFollow(' . $user['id'] . ', false)">Follow</button>';
            }
            
            echo '</div>'; // Closing div for 'searched-user'
        }
    } else {
        echo '<p>No results found.</p>';
    }
}
?>
