<?php
session_start();
require_once('../model/userModel.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id']) && isset($_POST['is_following'])) {
    $userId = $_POST['user_id'];
    $isFollowing = $_POST['is_following'] === 'true';

    $loggedInUsername = $_SESSION['username'];

    if ($isFollowing) {
        // Unfollow user
        unfollowUser($loggedInUsername, $userId);
    } else {
        // Follow user
        followUser($loggedInUsername, $userId);
    }
}
?>
