<?php
// upload_pictures.php

require_once('../model/userModel.php');

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];

        // Check if a file was uploaded
        if (isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
            $imageData = addslashes(file_get_contents($_FILES['picture']['tmp_name'])); 

            if (storePictureInfo($username, $imageData)) {
                $uploadResult = "Picture uploaded and stored successfully.";
            } else {
                $uploadResult = "Failed to store picture info in the database.";
            }
        } else {
            $uploadResult = "No picture uploaded or upload error occurred.";
        }
    } else {
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>StudyMate | Login</title>

    <style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .container {
        display: flex;
        flex-direction: column;
        width: 80%;
        max-width: 500px;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
    }

    header h1 {
        margin: 0;
        font-size: 24px;
    }

    header a {
        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }

    .links {
        margin-top: 20px;
        display: flex;
        flex-direction: column;
    }

    .links a {
        text-decoration: none;
        font-size: 18px;
        margin-bottom: 10px;
    }
</style>
</head>
<body>
<fieldset>
<fieldset>
    
<header>
        
        <a href="home.php"><h1>StudyMate</h1></a>

    <nav>

    

    </nav>
</header>

<div class="container">
                <div class="links">
                    <?php if (!empty($uploadResult)): ?>
                        <script>
                            alert("<?php echo $uploadResult; ?>");
                        </script>
                    <?php endif; ?>
                    <form action="" method="post" enctype="multipart/form-data">
                        <input type="file" name="picture" required>
                        <input type="submit" value="Upload">
                    </form>
                    <a href="home.php">Back</a>
                </div>

</fieldset>
</fieldset>
</body>
</html>