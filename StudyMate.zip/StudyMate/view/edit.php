<?php
session_start();

if (!isset($_SESSION['flag'])) {
    header('location: index.php');
    exit; 
}

require_once('../model/userModel.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $row = updateUser();
    if ($row === true) {
        
        header('Location: home.php');
        exit;
    } else {
        $error = 'Update failed. Please try again.';
    }
} else {
    
    $row = getUserInfo();
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudyMate | Edit Profile</title>
    <style>
        
        body {
            margin: 0;
            padding: 0;
        }

        
        body {
            background-color: #f0f2f5;
            font-family: Arial, sans-serif;
        }

        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #4267B2; 
            color: #fff;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header a {
            text-decoration: none;
            margin-left: 10px;
            font-size: 16px;
            color: #fff;
        }

        
        .picture-box {
            position: relative;
            width: 150px;
            height: 150px;
            border: 2px solid #ddd;
            overflow: hidden;
            border-radius: 50%;
            margin: 20px auto;
        }

        .picture-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        
        .content-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
        }

        
        ul {
            list-style: none;
            padding: 0;
        }

        ul li {
            margin-bottom: 10px;
        }

        ul li a {
            display: block;
            padding: 10px 15px;
            background-color: #f0f2f5;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.2s ease;
        }

        ul li a:hover {
            background-color: #ddd;
        }
    </style>
</head>

<body>
    <a href="home.php">Back</a> |

<fieldset>
<fieldset>

        <header>
            <a href="home.php"><h1>StudyMate</h1></a>
            
            <nav>
                <a href="#">Logged in as <?php echo $_SESSION['username']; ?></a>
                <a href="../controller/logout.php"> | Logout </a>
            </nav>
        </header>

        <h1>Edit Profile</h1>

        <?php if (isset($error) && !empty($error)): ?>
            <p><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post">
            <table>
                
            <tr>
                    <th>Name :</th>
                    <td><input type="text" name="name" value="<?php echo $row['name']; ?>"></td>
                </tr>
                <tr>
                    <th>Password :</th>
                    <td><input type="password" name="password" value="<?php echo $row['password']; ?>"></td>
                </tr>
                
                <tr>
                    <th>Email :</th>
                    <td><input type="email" name="email" value="<?php echo $row['email']; ?>"></td>
                </tr>
                <tr>
                    <th>Gender :</th>
                    <td><input type="text" name="gender" value="<?php echo $row['gender']; ?>"></td>
                </tr>
                <tr>
                    <th>Date of Birth :</th>
                    <td><input type="date" name="dateofbirth" value="<?php echo $row['dateofbirth']; ?>"></td>
                </tr>
            </table>
            <input type="submit" value="Update">
        </form>

</fieldset>
</fieldset>

</body>

</html>