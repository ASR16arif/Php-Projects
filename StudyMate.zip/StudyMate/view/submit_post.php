<?php
session_start();

if (!isset($_SESSION['flag'])) {
    header('location: index.php');
    exit();
}

require_once('../model/userModel.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_POST['postContent'])) {
        $postContent = trim($_POST['postContent']);

        
        if (!empty($postContent)) {
           
            $username = $_SESSION['username'];

            
            $result = createPost($postContent, $username);

            if ($result) {
                
                echo json_encode(['status' => 'success', 'message' => 'Post stored successfully.']);
            } else {
                
                echo json_encode(['status' => 'error', 'message' => 'Failed to store post in the database.']);
            }
        } else {
            
            echo json_encode(['status' => 'error', 'message' => 'Post content cannot be empty.']);
        }
    } else {
        
        echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    }
} else {
    
    header('ERROR');
}
?>
