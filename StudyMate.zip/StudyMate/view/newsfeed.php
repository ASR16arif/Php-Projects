<?php
session_start();

if (!isset($_SESSION['flag'])) {
    header('HTTP/1.1 401 Unauthorized');
    exit();
}

require_once('../model/userModel.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['postContent'])) {
    $postContent = trim($_POST['postContent']);
    if (!empty($postContent)) {
    
        $username = $_SESSION['username'];
        $result = createPost($postContent, $username);
        header('Location: newsfeed.php');
        exit();
    }
}

$posts = getAllPosts();

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudyMate | NewsFeed</title>
    <style>
        
        body {
            margin: 0;
            padding: 0;
        }

        
        body {
            background-color: #f0f2f5;
            font-family: Arial, sans-serif;
        }

        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #4267B2; 
            color: #fff;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header a {
            text-decoration: none;
            margin-left: 10px;
            font-size: 16px;
            color: #fff;
        }

        .picture-box {
            position: relative;
            width: 150px;
            height: 150px;
            border: 2px solid #ddd;
            overflow: hidden;
            border-radius: 50%;
            margin: 20px auto;
        }

        .picture-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            border-radius: 50%;
        }

        .content-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
        }


        ul {
            list-style: none;
            padding: 0;
        }

        ul li {
            margin-bottom: 10px;
        }

        ul li a {
            display: block;
            padding: 10px 15px;
            background-color: #f0f2f5;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.2s ease;
        }

        ul li a:hover {
            background-color: #ddd;
        }

        #search-bar {
            position: center;
            top: 60px;
            left: 40px;
            display: flex;
        }

        #search-input {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px 0 0 5px;
            padding: 5px 10px;
            flex: 1;
        }

        #search-button {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 0 5px 5px 0;
            padding: 5px 10px;
            cursor: pointer;
        }

        #search-results {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 10px;
        }

        #search-results ul {
            list-style: none;
            padding: 0;
        }

        #search-results ul li {
            margin-bottom: 5px;
        }
        .post { 
            position: relative;
            border: 1px solid #ddd;
            background-color: #fff;
            border-radius: 10px;
            margin-bottom: 20px;
            padding: 10px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .post .user {
            font-weight: bold;
            color: #4267B2;
        }

        .post .time {
            font-size: 12px;
            color: #777;
        }

        .post .content {
            margin-top: 10px;
        }
    </style>
    <script>
        function searchUsers() {
            const searchTerm = document.getElementById('search-input').value.trim();

            if (searchTerm === '') {
                return;
            }

            const xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById('search-results').innerHTML = xhr.responseText;
                }
            };
            xhr.open('POST', 'search_users.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.send('search_term=' + searchTerm);
        }
    </script>
</head>
<body>
    <fieldset>
        <fieldset>
            <header>
                <a href="home.php">
                    <h1>StudyMate</h1>
                </a>
                <div id="search-bar">
                    <input type="text" id="search-input" placeholder="Search for users...">
                    <button id="search-button" onclick="searchUsers()">Search</button>
                </div>
                <nav>
                    <a href="#">
                        Logged in as <?php echo $_SESSION['username']; ?>
                    </a>
                    <a href="../controller/logout.php"> | Logout </a>
                </nav>
            </header>

            <h3>NewsFeed</h3>

            <div id="search-results"></div>

            <?php
        
        $latestPicture = getLatestPicture();

        if ($latestPicture && $_SESSION['username'] === $latestPicture['username']) {
            echo '<div class="picture-box">';
            $base64 = base64_encode($latestPicture['image_data']);
            echo '<img src="data:image/jpeg;base64,' . $base64 . '" alt="' . $latestPicture['username'] . '">';
            echo '</div>';
        }
        ?>

            <div id="newsfeed">
            <button onclick="showPostForm()">Write Post</button>
            <div id="postForm" style="display: none;">
                <form method="post" action="newsfeed.php">
                    <textarea name="postContent"></textarea>
                    <button type="submit">Post</button>
                </form>
            </div>
            <div id="posts">
                <?php foreach ($posts as $post) : ?>
                    <div class="post">
                        <div class="user"><?php echo $post['username']; ?></div>
                        <div class="time"><?php echo $post['timestamp']; ?></div>
                        <div class="content"><?php echo $post['content']; ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <script>
            function showPostForm() {
                document.getElementById('postForm').style.display = 'block';
            }
        </script>
        
        </fieldset>
    </fieldset>
</body>
</html>
