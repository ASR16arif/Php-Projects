<?php 
   
    require_once('../model/userModel.php');

    session_start();
    
    if(isset($_POST['submit']))
    {
        
        $username = $_POST['username'];
        $password = $_POST['password'];

        $status = login($username, $password);

        if($username == "" || $password == ""){
            
            header('location: ../view/login.php?msg=null');
        }else if($status){
            
            $_SESSION['flag'] = 'true';
            $_SESSION['username'] = $username;

            header('location: ../view/home.php');
        }else if(($username == $_SESSION['flag'] = 'true') || $password == ""){
            
            header('location: ../view/login.php?msg=incorrect password');

            
        }
        else{
            
            header('location: ../view/login.php?msg=invalid');
        }
    }else{
        header('location: ../view/login.php');
    }
?>