<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

if ($_SESSION['username'] !== 'admin' && isset($_GET['course'])) {
    $selectedCourse = $_GET['course'];
} else {
    header('Location: userDashboard.php');
    exit();
}

$teacherName = $_SESSION['username'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $attendanceIds = $_POST['attendance'];

    foreach ($attendanceIds as $studentId) {
        // Update the total_attendance column for each student
        $sql = "UPDATE students SET total_attendance = total_attendance + 1 WHERE id = $studentId";
        $conn->query($sql);
    }

    header("Location: takeAttendance.php?course=" . urlencode($selectedCourse));
    exit();
}

$conn->close();
?>
