<!DOCTYPE html>
<html>
<head>
    <title>Courses</title>
</head>
<body>
    <h2>Courses</h2>
    <!-- Display the courses associated with the user from the database -->
    <?php
    // Establish database connection (replace with your database credentials)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "attendancemanagement";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $user = $_SESSION['username'];
    $sql = "SELECT course FROM courses_details WHERE user = '$user'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li>" . $row["course"] . "</li>";
        }
        echo "</ul>";
    } else {
        echo "No courses found.";
    }

    $conn->close();
    ?>
</body>
</html>
