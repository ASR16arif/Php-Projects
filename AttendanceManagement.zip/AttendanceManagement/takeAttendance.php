<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

if ($_SESSION['username'] !== 'admin' && isset($_GET['course'])) {
    $selectedCourse = $_GET['course'];
} else {
    header('Location: userDashboard.php');
    exit();
}

$teacherName = $_SESSION['username'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch students for the selected course
$sql = "SELECT * FROM students WHERE course_name = '$selectedCourse'";
$result = $conn->query($sql);

$students = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Attendance for <?php echo $selectedCourse; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
            padding: 0;
            font-size: 24px;
        }
        .header .logout {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2, p, ul, form, table {
            margin-top: 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #333;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #555;
        }
        a {
            color: #333;
            text-decoration: none;
            font-size: 16px;
            display: inline-block;
            margin-top: 10px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        
        <h1>National University</h1>
        <a class="logout" href="logout.php">Logout</a>
    </div>
    <div class="container">
        <a href="coursePage.php?course=<?php echo urlencode($selectedCourse); ?>">Back</a><br>
        
        <h1>Take Attendance for <?php echo $selectedCourse; ?></h1>

        <form action="processAttendance.php?course=<?php echo urlencode($selectedCourse); ?>" method="POST">
            <table border="1">
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Today's Attendance</th>
                    <th>Total Attendance</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?php echo $student['student_id']; ?></td>
                        <td><?php echo $student['student_name']; ?></td>
                        <td><input type="checkbox" name="attendance[]" value="<?php echo $student['id']; ?>"></td>
                        <td><?php echo $student['total_attendance']; ?></td>
                        <td>
                            <a href="updateStudentInfo.php?student_id=<?php echo $student['id']; ?>">Update</a> |
                            <a href="deleteStudent.php?student_id=<?php echo $student['id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <br>
            <input type="submit" value="Submit Attendance">
        </form>
        
        <?php if (isset($_GET['success']) && $_GET['success'] === 'updated'): ?>
            <p>Student information has been successfully updated.</p>
        <?php endif; ?>
    </div>
</body>
</html>
