<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header('Location: index.php');
    exit();
}

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course = $_POST['course'];
    $user = $_POST['user'];

    $sql = "INSERT INTO courses_details (course, user) VALUES ('$course', '$user')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Course added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>National University - Add Courses</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            overflow: hidden;
        }
        .header h1 {
            float: left;
            margin: 0;
            padding: 0;
            font-size: 24px;
        }
        .header .logout {
            float: right;
            color: #fff;
            text-decoration: none;
            font-size: 16px;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            margin-top: 0;
        }
        form {
            margin-top: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        input[type="submit"] {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #555;
        }
        a {
            color: #333;
            text-decoration: none;
            font-size: 16px;
            margin-top: 10px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>National University</h1>
        <a class="logout" href="logout.php">Logout</a>
    </div>
    <div class="container">
    <a href="adminDashboard.php">Back</a><br>
        <h2>Add Courses</h2>
        <form action="addcourses.php" method="POST">
            <label for="course">Course:</label>
            <input type="text" name="course" required><br>
            <label for="user">User:</label>
            <input type="text" name="user" required><br>
            <input type="submit" value="Add Course"><br>
        </form>
        
    </div>
</body>
</html>

