<?php
session_start();
$adminUsername = 'admin';
$adminPassword = 'admin123';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $adminUsername && $password === $adminPassword) {
        $_SESSION['username'] = $adminUsername;
        header('Location: adminDashboard.php');
    } else {
        $_SESSION['username'] = $username;
        header('Location: userDashboard.php');
    }
}
?>
