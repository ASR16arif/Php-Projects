<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

if ($_SESSION['username'] !== 'admin' && isset($_GET['course'])) {
    $selectedCourse = $_GET['course'];
} else {
    header('Location: userDashboard.php');
    exit();
}

$teacherName = $_SESSION['username'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentName = $_POST['student_name'];
    $studentID = $_POST['student_id'];
    
    // Insert student data into the database
    $sql = "INSERT INTO students (student_name, student_id, course_name, teacher_name) 
            VALUES ('$studentName', '$studentID', '$selectedCourse', '$teacherName')";
    
    if ($conn->query($sql) === TRUE) {
        header("Location: coursePage.php?course=" . urlencode($selectedCourse));
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student to <?php echo $selectedCourse; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
            padding: 0;
            font-size: 24px;
        }
        .header .logout {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2, p, ul, form {
            margin-top: 0;
        }
        form {
            margin-top: 20px;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #555;
        }
        a {
            color: #333;
            text-decoration: none;
            font-size: 16px;
            display: inline-block;
            margin-top: 10px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        <a class="logout" href="coursePage.php?course=<?php echo urlencode($selectedCourse); ?>">Back</a>
        <h1>National University</h1>
        <a class="logout" href="logout.php">Logout</a>
    </div>
    <div class="container">
    <a href="coursePage.php?course=<?php echo urlencode($selectedCourse); ?>">Back</a><br>
        <h1>Add Student to <?php echo $selectedCourse; ?></h1>

        <form action="addStudent.php?course=<?php echo urlencode($selectedCourse); ?>" method="POST">
            Student Name: <input type="text" name="student_name" required><br>
            Student ID: <input type="text" name="student_id" required><br>
            <input type="submit" value="Add Student">
        </form>
    
        
    </div>
</body>
</html>

