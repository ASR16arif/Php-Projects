<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

if ($_SESSION['username'] !== 'admin' && isset($_GET['student_id'])) {
    $selectedStudentId = $_GET['student_id'];
} else {
    header('Location: userDashboard.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete the student
$sql = "DELETE FROM students WHERE id = $selectedStudentId";

if ($conn->query($sql) === TRUE) {
    header('Location: userDashboard.php?course=' . urlencode($selectedCourse));
    exit();
} else {
    echo "Error deleting student: " . $conn->error;
}

$conn->close();
?>
