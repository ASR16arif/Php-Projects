<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

if ($_SESSION['username'] !== 'admin' && isset($_GET['student_id'])) {
    $selectedStudentId = $_GET['student_id'];
} else {
    header('Location: userDashboard.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process the form data to update student info
    $newStudentName = $_POST['new_student_name'];
    $newStudentID = $_POST['new_student_id'];

    $sql = "UPDATE students SET student_name = '$newStudentName', student_id = '$newStudentID' WHERE id = $selectedStudentId";

    if ($conn->query($sql) === TRUE) {
        header('Location: userDashboard.php?course=' . urlencode($selectedCourse) . '&success=updated');
        exit();
    } else {
        echo "Error updating student info: " . $conn->error;
    }
}

// Fetch student's current info
$sql = "SELECT * FROM students WHERE id = $selectedStudentId";
$result = $conn->query($sql);

if ($result->num_rows === 1) {
    $studentInfo = $result->fetch_assoc();
} else {
    echo "Student not found.";
    exit();
}

$conn->close();
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student Info</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
            padding: 0;
            font-size: 24px;
        }
        .header .logout {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
        }
        h1, h2, p, ul {
            margin-top: 0;
        }
        form {
            margin-top: 20px;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #555;
        }
        a {
            color: #333;
            text-decoration: none;
            font-size: 16px;
            display: inline-block;
            margin-top: 10px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>National University</h1>
        <a class="logout" href="logout.php">Logout</a>
    </div>
    <div class="container">
        <h1>Update Student Info</h1>

        <form action="updateStudentInfo.php?student_id=<?php echo $selectedStudentId; ?>" method="POST">
            New Student Name: <input type="text" name="new_student_name" value="<?php echo $studentInfo['student_name']; ?>"><br>
            New Student ID: <input type="text" name="new_student_id" value="<?php echo $studentInfo['student_id']; ?>"><br>
            <input type="submit" value="Update">
            <a href="userDashboard.php">Cancel</a>
        </form>
    </div>
</body>
</html>
