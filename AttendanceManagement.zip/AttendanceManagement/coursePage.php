<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

if ($_SESSION['username'] !== 'admin' && isset($_GET['course'])) {
    $selectedCourse = $_GET['course'];
} else {
    header('Location: userDashboard.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $selectedCourse; ?> Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
            padding: 0;
            font-size: 24px;
        }
        .header .logout {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2, p, ul {
            margin-top: 0;
        }
        h2 {
            font-size: 20px;
            margin-bottom: 15px;
        }
        a {
            color: #333;
            text-decoration: none;
            font-size: 16px;
            margin-bottom: 10px;
            display: inline-block;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        
        <h1>National University</h1>
        <a class="logout" href="logout.php">Logout</a>
    </div>
    <div class="container">
        <a class="logout" href="userDashboard.php">Back</a><br>
        <h1><?php echo $selectedCourse; ?></h1>

        <h2>Actions for <?php echo $selectedCourse; ?>:</h2>
        <a href="addStudent.php?course=<?php echo urlencode($selectedCourse); ?>">Add Student</a><br>
        <a href="takeAttendance.php?course=<?php echo urlencode($selectedCourse); ?>">Take Attendance</a><br>
    </div>
</body>
</html>

