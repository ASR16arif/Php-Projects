<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "attendancemanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$courses = array();

if ($_SESSION['username'] !== 'admin') {
    // Fetch the courses assigned to the user from the database
    $user = $_SESSION['username'];
    $sql = "SELECT course FROM courses_details WHERE user = '$user'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $courses[] = $row['course'];
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>National University - User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
            padding: 0;
            font-size: 24px;
        }
        .header .logout {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2, p, ul {
            margin-top: 0;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        ul li {
            margin-bottom: 10px;
        }
        p {
            font-size: 18px;
            margin-bottom: 20px;
        }
        ul li a {
            color: #333;
            text-decoration: none;
            font-size: 16px;
        }
        ul li a:hover {
            text-decoration: underline;
        }
        ul.course-list {
            display: flex;
            flex-wrap: wrap;
            padding: 0;
            list-style: none;
        }
        .course-box {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            margin: 5px;
            border-radius: 5px;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>National University</h1>
        <a class="logout" href="logout.php">Logout</a>
    </div>
    <div class="container">
        <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>

        <?php if ($_SESSION['username'] === 'admin'): ?>
            
        <?php else: ?>
            <p>Your Courses:</p>
            <ul class="course-list">
                <?php foreach ($courses as $course): ?>
                    <li class="course-box"><a href="coursePage.php?course=<?php echo urlencode($course); ?>"><?php echo $course; ?></a></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</body>
</html>
